# 午後のFPGA — セッション分析・実装状況・今後の深い計画

作成: 2026-11-15 / 対象セッション: `876fba8b52d442c9ac197f5aa1ec108e`（fpga.moeの操作レビュー） / 基準リポジトリー: `uist1idrju3i/gogo-fpga` main `e3c6e76`

---

## 1. 対象セッションの分析

### 1.1 セッションが行ったこと

- Chromium を CDP 経由で操作し、fpga.moe（公開版 `fdd38db`、Cloudflare Pages）を 12 領域で網羅レビュー。
- プロジェクト作成→HDL編集→合成（Verilog 1K / VHDL-2019 9K）→配置配線→シミュレーション→Surfer 波形→仮想 USB 書き込み（SRAM/内蔵/外付け・読出し・消去）→ライブラリカタログ→ZIP/OPFS→形式検証→AI タブ→狭幅レイアウト。
- 証拠: `events.jsonl` 155 行、スクリーンショット 83 枚、REPORT.md、USER-ACTIONS.md。

### 1.2 結果の評価

- 11/12 領域が正常。コンソールエラー・ページエラー・リクエスト失敗は 0 件 — 製品の完成度は高い。
- レビューの質自体も良好：fail-closed の正常系エラーパス（IDCODE 不一致、破損 ZIP、消去確認ダイアログ、stale 成果物）まで確認済み。
- 指摘 2 件はどちらも本物で、片方は公開版の実害バグ。後述の通り原因をコードレベルで確認した。

### 1.3 セッションの限界（参考）

- Cloudflare Analytics の指摘は「Pages 自動挿入と思われる」止まりで、OFF にする具体的な設定箇所（Pages プロジェクトの Web Analytics トグル）まで掘っていない。
- 修正・PR は行っていない（レビュー依頼だったので妥当）。
- 実機・OpenRouter 実アカウントは範囲外で、これも依頼どおり。

---

## 2. 全体計画に対する現在の実装状況

RESEARCH.md の T0–T6 系列と S 実験群を基準に、main（`e3c6e76`）と公開版（`fdd38db`）を突き合わせた。

| 段階 | 内容 | 状態 |
|---|---|---|
| T0 | 書き込み部移植（openFPGALoader WASM・JSPI・仮想 USB） | 完了・公開版で動作確認済み |
| 合成系 | Yosys・nextpnr・GHDL の WASI 化、Pyodide 上の Apicula、.fs 生成 | 完了・公開版で 1K/9K の合成を確認 |
| シミュレーション | Icarus WASM→VCD→Surfer | 完了・公開版で確認 |
| T5 | HDL ライブラリー・CPU カタログ 22 候補 | 完了・公開版で確認 |
| 配信 | `public_html` 集約、Pages 承認 PR フロー、COOP/COEP、25 MiB 上限 | 完了・運用中 |
| AI タブ | OpenRouter OAuth PKCE、送信前確認、差分提案 | 実装済み・未接続確認のみ（実アカウント未検証） |
| **T6 形式検証** | SBY・SMTBMC・Yosys SAT・ソルバー・反例再実行・画面 | **画面まで実装済みだが配信物が未完成（= 今回の障害）** |
| 依存監視 | Dependabot + 固定版の更新確認 Issue #21 | 運用中・多数の更新候補あり |

### 2.1 形式検証の正確な断

画面（設定パネル・実行/停止・結果表示・反例 VCD→Surfer）は PR #83–#85 で main に入り、公開版にも載っている。失敗の連鎖は次の通り。

1. `web/lib/formal-assets.mjs` の `loadPythonBundle()` が `formal/python/manifest.json` を fetch。
2. `scripts/build-web.sh` は `public_html/formal/` を生成しない。`scripts/build-formal-python.py`（SBY・yosys-smtio・click の pin 取得 + process patch 適用 + manifest 生成）は probe/試験経路からしか呼ばれない。
3. Cloudflare Pages は未存在パスに `index.html`（200, text/html）を返す。
4. コードは `response.ok` しか見ず `.json()` を呼ぶ → `Unexpected token '<'` → `loadAll()`（`Promise.all`）全体が reject。
5. `web/ide.mjs` が「形式検証に失敗しました」＋生の JSON パースエラーを表示。

**重要な副次発見**: Yosys SAT 経路（既定 engine）は `input.assets.yosys`（既配信の `synth/` 資材）だけで動く設計で、Python bundle を必要としない。つまり `loadPython()` の失敗を局所化するだけで、公開版は即座に SAT 形式検証が動く状態になる。

さらに `loadAll()` は `solvers: {}` をハードコードで返す。Yices2/Z3 の WASI バイナリーを取得する経路が製品側に一切ない。solver 診断ビルドは `scripts/build-solver-probe.py`（「without replacing product assets」と明記）で実験的に作られており、製品資材のビルド・manifest・配信は未実装。

### 2.2 形式検証で残っている全項目

コードと docs/research/* の突き合わせで確定した残件：

- **配信漏れ（公開版の障害そのもの）**: `formal/python/` を build-web.sh / CI / release に組み込む。
- **solver 資材の製品化**: Yices2・Z3 の WASI 製品ビルド経路、manifest＋sha256、zstd 圧縮配信（`verified-assets.mjs` が `encoding:"zstd"` に対応済み）。Z3 は生 31.5 MB だが zstd-19 で 5.2 MB になることが S15 で実測済み。25 MiB 上限に収まる。
- **エラー局所化**: `loadPythonBundle` が HTML フォールバックで落ちないようにする（Content-Type 確認または `.json()` を try/catch → null）。SAT は動き、SMTBMC/SBY は既存の `missing-assets` 経路で案内できる。
- **`.sby` 指定ファイル**: runner は「プロジェクト指定の .sby ファイルはまだ接続されていません」を返す。
- **他 SBY engine**: abc/aiger/btor/itp は未実装（capabilities の blockers どおり）。cover mode、複数 slot も残件。
- **追加 solver**: Bitwuzla・Boolector は診断・正式反復まで済みだが `product-unqualified` で無効。製品認定（依存の配布条件・ライセンス closure）が未完了。
- **文書の陳腐化**: `formal-capabilities.md` の「画面への表示はまだ未接続」、`formal-verification.md` の「ブラウザーの形式検証画面は未完了」は #85 で解消済みのため、配信後に更新が必要。
- **ライセンス**: Yices2 は GPL。コンパイル済み WASM の配布は revision 固有のソース提供義務を伴う（RESEARCH.md §8 の未確認事項）。Z3 は MIT なので先行投入の候補。
- **既定 solver 未決定**: S15-solver-native-wasi は「どちらを製品の既定にするかは決めていない」。

### 2.3 形式検証以外の残件

- **Cloudflare Web Analytics**: `static.cloudflareinsights.com/beacon.min.js` を毎回外部読込み。CSP の `connect-src` で計測送信は遮断されるはずだが、`script-src` 未指定のため取得自体は外部通信。「送信先は openrouter.ai だけ」の方針と齟齬。Pages 側の Web Analytics OFF が最短解（ユーザー作業）。
- **依存更新 Issue #21**: zlib 1.4、emsdk 7.0.0、yosys v0.71、Node 26、Rust 1.100、third_party ライブラリー各種、click 8.5.1 など多数。vendor-update スキルの手順（変更履歴・採否・回帰）で個別対応が必要。solver 系の「最新」表示はタグ選定のノイズを含む（boolector が smtcomp-2018 など）。
- **RESEARCH.md §8 の未確認事項**: 実機 4 ボード、OpenRouter 実アカウント、NVC interpreter 完走、SystemVerilog/Verilator、sv-elab WASM、非 Chromium、4 MiB 全量読出し時間、GPL 配布のソース提供義務。
- **main は公開版より 1 commit 先行**（#24 ブランチ自動削除）。次回 main ビルド成功で pages-update PR が生成される流れ。

---

## 3. 今後の深い計画

優先度は「公開版の実害 → 機能の完結 → 拡張 → 運用品質」の順。各段階は独立してマージ可能な単位で分割する。

### 段階 0: 公開版の形式検証の即応修正（小 PR・最優先）

目的: 既配信資材だけで動く Yosys SAT を公開版で動かし、SMTBMC/SBY は明確な案内に変える。

1. `loadPythonBundle()` を fail-closed かつ非致命的に修正: Content-Type または JSON パース失敗を `null` として扱う（資材不在を「破損」と区別しないよう、manifest 取得失敗と検証失敗は別の理由でログに残す）。
2. `loadAll()` の `loadPython()` に `.catch(() => null)` 相当の局所化（既に `loadYosys` 側は同様の `.catch` あり — 対称にする）。
3. `ide.mjs` の catch で、資材不在系の失敗は「この配信には形式検証の資材が含まれていません」等の原因が分かる表示にする（SMTBMC 実行時の `missing-assets` 経路は既存）。
4. テスト: `tests/web/formal-assets.test.mjs` に「HTML 200 を返す環境で null を返し SAT 経路が継続する」ケースを追加。
5. 検証: `node --test tests/web/*.test.mjs` と lint 一式。画面変更に伴う 4 ボード相当の目視確認（AGENTS.md の画面確認手順）。
6. 効果: この PR だけで公開版は「Yosys SAT の bmc/prove が実行できる」状態に復帰。

### 段階 1: `formal/python/` の配信組み込み

目的: SBY/SMTBMC の Python 層を配信物に載せる（solver はまだ無くてもよい）。

1. `scripts/build-formal-python.py --out public_html/formal/python` を `build-web.sh` に追加。出力が loader の期待（`python/manifest.json` + `python/<path>` + sha256/size）と一致することを確認する単体検査。
2. 生成物のライセンス取り扱い: build-formal-python.py は `licenses/<name>-<license>` を bundle 内に書く。`public_html/licenses/` 方針・THIRD_PARTY_NOTICES.md との整合を確認し、重複が許容か置き場を一本化するか決める。
3. `check-dist-size.py` の対象に含まれること、`_headers` の CSP で同一オリジン配信であることを確認（変更不要なはず）。
4. CI `build.yml` と `release.yml` への組み込み、CI 成果物に `formal/` が含まれることの検査追加。
5. `tests/web/formal-assets.test.mjs` 等の既存試験を実配信形態に合わせて再確認。
6. この段階でも solver が無いため SMTBMC/SBY 実行は `missing-assets`。ただし Pyodide worker・manifest 検証・ハッシュ照合の全経路が実配信で通る。

### 段階 2: solver WASI 資材の製品化（最大の工数）

目的: Yices2/Z3 を実際に配信・実行可能にする。

1. **製品ビルドスクリプト**（新規 `scripts/build-formal-solvers.sh` 相当）: `build-solver-probe.py` の診断手順を製品用に転記 — 固定 WASI SDK、Yices2 は固定 GMP 6.3.0、Z3 は static・単一 thread、`patches/yices2/`、`patches/z3/` の適用、バージョン表記の再現性。
2. **manifest 生成**: 各 solver の wasm、sha256、size、`encoding:"zstd"`、exitCodes ポリシー（`formal-python-process.mjs` が参照）を `formal/solvers/manifest.json` に生成。`verified-assets.mjs` の形式に合わせる。
3. **loader 拡張**: `formal-assets.mjs` の `loadAll()` で solver manifest を読み `solvers` map を構築（`createVerifiedAssetLoader` を `formal/` 向けに再利用）。
4. **圧縮**: zstd-19 の host 側梱包とブラウザー内展開（`decompress.mjs` 経路の再利用）。Z3 の S15 実測値（31.5 MB→5.2 MB）を前提確認。Yices2 のサイズを計測してから同様に扱う。
5. **ライセンス判断（ユーザー確認事項 A）**: Z3（MIT）だけ先行するか、Yices2（GPL、ソース提供義務の整備が要る）も同時に載せるか。GPL の配布義務（revision 固有のソース提供・表示）は RESEARCH.md §8 の未解決事項と直結。
6. **既定 solver（ユーザー確認事項 B）**: S15 は既定を決めていない。候補: Z3（ライセンス簡単・size 大きめ）、Yices2（軽量だが GPL）。推奨: Z3 を既定・Yices2 を選択肢。
7. **認定の形式化**: S15 の正式反復（native/WASI 全列監査）を製品ビルドの資材に対しても実施 — 製品バイナリーが診断バイナリーと同一 hash なら再利用可能、違うなら監査の範囲を experiment-record で記録。
8. E2E: 仮想環境で SMTBMC bmc/prove/cover が Surfer 連携まで通ることを確認。

### 段階 3: 形式検証の機能拡張（優先度はユーザー判断）

- プロジェクト `.sby` ファイル指定の接続。
- cover mode、複数 slot。
- 追加 SBY engine（abc/aiger/btor/itp）。
- Bitwuzla/Boolector の製品認定、または候補整理。
- SystemVerilog（sv-elab）、Verilator — RESEARCH.md §8 の将来段階。

### 段階 4: 運用・周辺品質

- **Cloudflare Analytics**（ユーザー作業）: Pages の Web Analytics OFF、または方針文書へ「計測送信は CSP で遮断」の旨を明記。
- **依存更新**（Issue #21）: vendor-update スキルで個別採否。優先候補: zlib（安全関連の可能性）、emsdk 7.0.0、Node 26、yosys v0.71。
- **文書更新**: `formal-capabilities.md`、`formal-verification.md`、RESEARCH.md §7/#8 の「画面未接続/未完了」を配信後の状態へ。
- **実機確認**（ユーザー作業）: pages-update PR の preview で Tang Nano 実機確認 — これは既定の公開承認フローそのもの。
- **OpenRouter 実アカウント**: A1/A2 の模擬応答を超えた確認（アカウント必要）。
- **非 Chromium ブラウザー**: Firefox/Safari での COOP/COEP・SharedArrayBuffer・WebUSB の互換調査（WebUSB は Chromium 系のみ — 書き込み以外の機能分離を整理する価値あり）。

---

## 4. ユーザーに判断・作業いただくこと

| # | 事項 | 選択肢・推奨 |
|---|---|---|
| A | Yices2（GPL）の WASM 配布 | Z3（MIT）のみ先行が推奨。Yices2 同梱なら revision 固有のソース提供義務の整備が先 |
| B | 既定 solver | 推奨: Z3 を既定、Yices2 を選択肢（ライセンスとサイズの均衡） |
| C | Cloudflare Web Analytics | Pages プロジェクトの Web Analytics を OFF（推奨。方針「送信先は openrouter.ai だけ」と整合） |
| D | 段階 0（SAT 復旧）だけ先に公開するか | 推奨: 先に公開。資材なしでも SAT が動き、障害の見た目が消える |
| E | 実機 Tang Nano 確認 | 次の pages-update PR の preview で実施（既存フロー） |
| F | OpenRouter 実アカウント検証 | 実アカウント・課金の可否をご判断ください |

## 5. 推奨する直近の着手順

1. 段階 0 の PR（資材不在の局所化 + SAT 復旧 + 試験 1 件）。
2. 段階 1 の PR（`formal/python/` 配信組み込み）。
3. ユーザー判断 A/B/C の回答を待つ間に、段階 2 の製品ビルドスクリプトの設計（Z3 先行想定）。
4. Issue #21 のうち安全関連（zlib 等）の採否評価。
