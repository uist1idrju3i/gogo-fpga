# ユーザー側で確認・判断いただきたいこと

## 対応が必要そうな点

1. **形式検証の配信漏れ**: 公開版 fpga.moe で形式検証が常に失敗します。`public_html/formal/` が配信物に含まれないことと、`loadPythonBundle()` が SPA フォールバックの HTML を JSON として解析して例外になることの 2 点が原因です。配信物に `formal/python/` を載せるか、資材が無い環境では機能自体を無効化・案内するかの判断が要ります。
2. **Cloudflare Web Analytics**: Pages 側の自動挿入で `static.cloudflareinsights.com/beacon.min.js` が毎回読み込まれます。CSP で計測送信は遮断される想定ですが、「送信先は openrouter.ai だけです」の方針との整合をご確認ください。不要なら Pages プロジェクトの Web Analytics を OFF にする手があります。

## このレビューで確かめられないこと

- 実機の Tang Nano への書き込み（今回は仮想デバイスのみ）。
- OpenRouter 接続後の AI 相談機能（アカウント認証が必要）。
- 4 MiB 全量フラッシュ読み出しの完了時間。

## 補足

- ブラウザの OPFS に検証用プロジェクト（`blink`、`review-vhdl`、`review-verilog-copy`）が残っています。不要ならプロジェクト切替メニューから削除できます。
- 検証中に `blink` の制約ファイルを一度 9K 向けに置き換え、修復機能で 1K へ戻したため、`constraints/` に `.bak.txt` が 2 件残っています。
