# fpga.moe レビュー報告

- 対象: https://fpga.moe （公開版 fdd38db・Cloudflare Pages 配信）
- 日時: 2026-11-15（JST）
- 方法: 実ブラウザ（Chromium）を CDP 経由で操作し、コンソール・ネットワーク・ページエラー・スクリーンショットを全記録。書き込み系はリポジトリの仮想 USB デバイス（`tests/sim/fake-webusb.mjs`）で検証。**実機の Tang Nano では試していません。**

## 検証済み項目（全 12 領域）

| # | 領域 | 結果 |
|---|---|---|
| 1 | 初期ロード・対応判定・ウェルカム | OK |
| 2 | プロジェクト作成・切替（4 ボード × VHDL/Verilog、重複名） | OK |
| 3 | ファイル操作（追加・改名・削除・アップロード・パス検証） | OK |
| 4 | エディタ（保存・補完・問題パネル・ライブラリ読み取り専用） | OK |
| 5 | 合成・配置配線（Verilog 1K / VHDL-2019 9K → .fs 成果物） | OK |
| 6 | シミュレーション → VCD → Surfer 波形・DL | OK |
| 7 | 書き込み UI（仮想デバイスで SRAM/内蔵/外付け・読み出し・消去） | OK |
| 8 | HDL ライブラリー・CPU カタログ（22 候補・追加・解除・読み取り専用） | OK |
| 9 | ZIP 書き出し/読み込み・OPFS 永続化 | OK |
| 10 | 形式検証パネル | **常に失敗（要対応）** |
| 11 | AI タブ（OpenRouter） | 未接続まで確認。外部送信なし |
| 12 | 狭幅レイアウト（840px / 420px） | OK |

## 発見した問題

### 1. 形式検証が公開版で必ず失敗する（重要度高）

- 現象: 検証タブから形式検証を実行すると「形式検証に失敗しました。」。ログには `形式検証エラー: Unexpected token '<', "<!doctype "... is not valid JSON`。
- 原因（ソース確認済み）
  1. `web/lib/formal-assets.mjs` の `loadPythonBundle()` が `formal/python/manifest.json` を fetch する。
  2. 公開版には `formal/` 配下の資材が無い（`scripts/build-web.sh` は `public_html/formal/` を生成しない。`scripts/build-formal-python.py` は probe 系スクリプトからしか呼ばれない）。
  3. Cloudflare Pages は存在しないパスに SPA フォールバックとして `index.html`（HTTP 200, text/html）を返す。
  4. コードは `response.ok` だけ見て `manifestResponse.json()` を呼ぶため、HTML を JSON として解析して例外になる。
- 影響: 資材取得が失敗するため、エンジン（Yosys SAT / SBY・SMTBMC）に関わらず形式検証は実行できない。エンジン・ソルバーの UI（Yices2・Z3 が選択可、他は「未対応」表示）は正常に動く。
- エラー UX の観点でも、生の JSON パースエラーがそのままログに出るのは改善余地あり（「資材が公開版に含まれていません」等の原因が分かる表示が望ましい）。
- 証拠: `shots/15b-formal-run.png`、`shots/15c-formal-reason.png`。`curl https://fpga.moe/formal/python/manifest.json` → 200 + `<!doctype html>`。

### 2. 外部リクエスト: Cloudflare Web Analytics（重要度低・方針確認）

- 全ページロードで `https://static.cloudflareinsights.com/beacon.min.js` を読み込む（12 回のリロードすべてで観測）。Cloudflare Pages の自動挿入と思われる。
- CSP は `connect-src 'self' https://openrouter.ai` のため、ビーコンの計測送信は遮断されるはずだが、`script-src` が無いためスクリプトの取得自体は外部通信になる。方針「送信先は openrouter.ai だけです」との整合を確認する価値あり。それ以外の外部通信（openrouter.ai への送信を含む）は未接続状態では一切発生しないことを確認。

### 3. コンソール警告（環境起因・バグではない）

- GPU なし VM 固有の警告のみ: preload integrity 無視通知（`/surfer/`）、ソフトウェア WebGL 非推奨、ReadPixels GPU stall。ページエラー・コンソールエラー・リクエスト失敗は全工程で 0 件。

## 確認できた正常なエラーパス（fail closed）

- 空の `top` モジュールで合成 → 「Module `top` not found」をログと問題パネルに表示。
- プロジェクト名重複 → 「同じ名前のプロジェクトがすでにあります。」（作成・ZIP 読み込みの両方）。
- 破損 ZIP → 「ZIP ファイルの終端情報がありません。」
- オフセット `abc` → 「オフセットは 0 以上の整数で指定してください。」＋実行ボタン無効。
- 1K 用 .fs を 9K プロジェクトで選択 → 「選択したファイルの IDCODE をボードと照合できません。」＋書き込みボタン無効（デバイスを要求しない fail closed）。
- 消去操作 → 「フラッシュの内容がすべて消えます」確認ダイアログ。キャンセル・Esc の両方で USB 要求なしに中断。
- リロード復元した成果物は「古い（stale）」と表示し、再合成を案内 → 正しい設計どおり。
- ボードと制約ファイルの不一致 → 警告＋「選択したボードの clk / led 用制約を生成する」で修復（元ファイルは `.bak.txt` 退避、警告解消を往復で確認）。

## 主な検証結果の数値

- 合成（Verilog, Tang Nano 1K, blink テンプレート）: 約 9 秒、Fmax 177.30 MHz、LUT4 37/1152、警告 0。
- 合成（VHDL-2019, Tang Nano 9K）: 約 6 秒、Fmax 182.92 MHz、LUT4 37/8640。
- シミュレーション: Icarus Verilog WASM で `top_tb` 実行 → VCD 生成 → Surfer 描画・`wave.vcd` DL（内容確認済み）。
- 書き込み（仮想 9K）: SRAM「成功」（`Load SRAM: 100.00%Done DONE`）、内蔵フラッシュ「成功」（`Erase FLASH DONE … write Flash: 100.00%Done`）。
- 読み出し（仮想 9K、外付けフラッシュ先頭+0x100 から 4 B）: 「成功」、`tangnano9k-flash-0x100-4.bin`（内容 `ffffffff`）DL。
- 一括消去（仮想 20K）: 確認後「成功」（`bulk_erase` → `Done`）。
- 4 MiB 全量読み出しは BSCAN（1 ビットずつの JTAG 駆動）経路で非常に低速。「May take time」の警告どおりで、90 秒では完了しない（異常ではなく想定内のコスト。UI に小容量・カスタムサイズ選択肢あり）。
- ZIP: 書き出し（project.json + 全ファイル）→ 改名して読み込み → 別プロジェクトとして復元、リロード後も OPFS に永続化。
- ライブラリ: Colibri を追加 → `libraries/colibri/` 以下にソースとライセンスを展開、エディタで読み取り専用、`選択を解除` で完全に除去。
- レイアウト: 840px は 3 カラム維持（エディタ約 274px、やや狭いが使用可）。420px はモバイルモード（下部アクションバー＋シート式ペイン、はみ出しなし）。

## 記録の所在

- 全イベントログ: `events.jsonl`（155 行）
- スクリーンショット: `shots/` 83 枚
- 取得物: `wave.vcd`、`dump-small.bin`、`review-verilog.zip`、`tangnano1k-top.fs`（1K 成果物、IDCODE 不一致試験用）

## 残課題（このレビューで確かめられなかったもの）

- 実機の Tang Nano への書き込み（仮想デバイスの結果は実機の値ではない）。
- OpenRouter への接続以降の AI 相談機能（アカウントが必要）。
- 4 MiB 全量フラッシュ読み出しの完了時間（仮想デバイスでは実用上の上限を測りきれない）。
- Bitwuzla・Boolector 等「未対応」ソルバーの個別の選択不可理由の表示（一覧では「（未対応）」と括弧書きされる）。
