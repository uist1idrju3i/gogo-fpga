"""Verify the audit archive without extracting untrusted paths."""
import csv
import hashlib
import io
import json
import sys
import zipfile


def main():
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python3 verify-evidence.py evidence.zip')
    with zipfile.ZipFile(sys.argv[1]) as archive:
        names = archive.namelist()
        assert len(names) == len(set(names)), 'Duplicate ZIP members'
        assert all(not n.startswith('/') and '..' not in n.split('/') for n in names)
        assert archive.testzip() is None, 'ZIP CRC error'
        rows = list(csv.DictReader(io.StringIO(archive.read('evidence-files.csv').decode())))
        assert set(names) == {r['path'] for r in rows} | {'evidence-files.csv'}
        for row in rows:
            data = archive.read(row['path'])
            assert len(data) == int(row['bytes']), row['path']
            assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
        with zipfile.ZipFile(io.BytesIO(archive.read('attachments/shots-all.zip'))) as shots:
            assert shots.testzip() is None
            assert sum(n.lower().endswith('.png') for n in shots.namelist()) == 90
        events = archive.read('attachments/events.jsonl').decode().splitlines()
        assert len(events) == 166
        for line in events:
            json.loads(line)
        for session_id, count in [
            ('876fba8b52d442c9ac197f5aa1ec108e', 2067),
            ('d0a110d3f84f4346b049bc0f51829f8e', 643),
        ]:
            events = [json.loads(l) for l in archive.read(
                f'sessions/{session_id}/events.jsonl').decode().splitlines()]
            assert len(events) == count
            assert len({e['event_id'] for e in events}) == count
            details = [json.loads(l) for l in archive.read(
                f'sessions/{session_id}/event-details.jsonl').decode().splitlines()]
            assert {e['event_id'] for e in details} == {e['event_id'] for e in events}
            assert all('contents' in e or e.get('details_omitted') == 'internal_session_state' for e in details)
        assert sum(len(archive.read(f'sessions/{s}/actions.jsonl').splitlines()) for s in [
            '876fba8b52d442c9ac197f5aa1ec108e', 'd0a110d3f84f4346b049bc0f51829f8e']) == 597
        print(json.dumps({'status': 'pass', 'files_hashed': len(rows),
                          'zip_members': len(names), 'session_events': 2710,
                          'browser_events': 166, 'png_images': 90}))


if __name__ == '__main__':
    main()
