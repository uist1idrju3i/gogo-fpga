// Diagnostic only: exercises the current loader with controlled HTTP responses.
// Synthetic bytes are deliberately not executable Yosys assets.
import assert from 'node:assert/strict';
import { pathToFileURL } from 'node:url';

const root = process.argv[2];
if (!root) throw new Error('Usage: node diagnose-assets.mjs <repository-root>');
const { createFormalAssetLoader } = await import(pathToFileURL(`${root}/web/lib/formal-assets.mjs`));
const source = new TextEncoder().encode('synthetic fixture, not executable wasm');
const synthLoader = {
  async loadManifest() { return {}; },
  async openCache() { return null; },
  async fetchVerifiedAsset() { return source; },
};
for (const status of [404, 200]) {
  let fetchCount = 0;
  const loader = createFormalAssetLoader({
    synthLoader,
    fetchImpl: async () => {
      fetchCount++;
      return new Response('<!doctype html><html>SPA fallback</html>', {
        status, headers: { 'Content-Type': 'text/html' },
      });
    },
  });
  const attempts = [];
  for (let i = 0; i < 2; i++) {
    try {
      const assets = await loader.loadAll();
      attempts.push({ outcome: 'resolved', yosysPresent: !!assets.yosys,
        pythonSources: assets.sources.length, pythonManifest: assets.manifest,
        solvers: Object.keys(assets.solvers) });
      assert.equal(status, 404);
      assert.equal(assets.sources.length, 0);
    } catch (error) {
      assert.equal(status, 200);
      assert.equal(error.name, 'SyntaxError');
      attempts.push({ outcome: 'rejected', error: error.name,
        message: error.message });
    }
  }
  assert.equal(fetchCount, 1);
  console.log(JSON.stringify({ status, contentType: 'text/html', fetchCount, attempts }));
}
