"""Assemble local research evidence; never modifies original attachments."""
import argparse
import base64
import collections
import csv
import hashlib
import io
import gzip
import json
import os
from pathlib import Path
import re
import subprocess
import zipfile


PUBLIC_EVENT_TYPES = {
    'initial_user_message', 'user_message', 'devin_message',
    'user_question_answered', 'shell_process_started',
    'shell_process_completed', 'shell_process_completed_background',
    'terminal_update', 'multi_read_result', 'multi_edit_result',
    'todo_update', 'search_file_commands', 'mcp_tool_call_started',
    'mcp_tool_call', 'attachment_live_update', 'citation_snippet',
}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--exports', type=Path, required=True)
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--attachments', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    data = {}
    original_hashes = {}
    inventory = json.loads((args.exports / 'attachment-inventory.json').read_text())
    for row in inventory:
        candidates = list(args.attachments.glob(f'*/{row["name"]}'))
        matches = [p for p in candidates if hashlib.sha256(p.read_bytes()).hexdigest() == row['sha256']]
        assert len(matches) == 1, row['name']
        content = matches[0].read_bytes()
        assert len(content) == row['bytes']
        data[f'attachments/{row["name"]}'] = content
        original_hashes[row['name']] = row['sha256']

    coverage = json.loads((args.exports / 'coverage.json').read_text())
    for session_id, stats in coverage.items():
        events = [json.loads(l) for l in (args.exports / f'{session_id}-all-events.jsonl').read_text().splitlines()]
        safe_events = []
        for event in events:
            if event['type'] in PUBLIC_EVENT_TYPES:
                safe_events.append(event)
            else:
                safe_events.append({k: event[k] for k in ['event_id', 'type', 'timestamp'] if k in event} |
                                   {'details_omitted': 'internal_session_state'})
        assert len(safe_events) == stats['events']
        data[f'sessions/{session_id}/events.jsonl'] = ''.join(json.dumps(e, ensure_ascii=False) + '\n' for e in safe_events).encode()
        details = [json.loads(l) for l in (args.exports / f'{session_id}-shareable-details.jsonl').read_text().splitlines()]
        assert {e['event_id'] for e in details} == {e['event_id'] for e in safe_events}
        data[f'sessions/{session_id}/event-details.jsonl'] = ''.join(json.dumps(e, ensure_ascii=False) + '\n' for e in details).encode()
        terminal_count = 0
        for event in details:
            if event['type'] != 'terminal_update':
                continue
            content = event.get('contents', {})
            terminal = None
            if content.get('contents_gzip'):
                terminal = gzip.decompress(base64.b64decode(content['contents_gzip']))
            elif isinstance(content.get('contents'), str):
                terminal = content['contents'].encode()
            if terminal is not None:
                data[f'sessions/{session_id}/terminal/{event["event_id"]}.txt'] = terminal
                terminal_count += 1
        stats['terminal_payloads_decoded'] = terminal_count
        original_actions = [json.loads(l) for l in (args.exports / f'{session_id}-actions.jsonl').read_text().splitlines()]
        action_ids = {e['event_id'] for e in original_actions}
        actions = [e for e in safe_events if e['event_id'] in action_ids]
        assert len(actions) == len(original_actions)
        data[f'sessions/{session_id}/actions.jsonl'] = ''.join(json.dumps(e, ensure_ascii=False) + '\n' for e in actions).encode()
        data[f'sessions/{session_id}/timeline.tsv'] = ('event_id\ttype\ttimestamp\n' + ''.join(
            f'{e["event_id"]}\t{e["type"]}\t{e.get("timestamp", "")}\n' for e in safe_events)).encode()
        data[f'sessions/{session_id}/messages.json'] = (args.exports / f'{session_id}-messages.json').read_bytes()
        data[f'sessions/{session_id}/commands.txt'] = (args.exports / f'{session_id}-commands.txt').read_bytes()
        stats['action_index_events'] = len(actions)
        stats['shared_body_events'] = sum(e['type'] in PUBLIC_EVENT_TYPES for e in safe_events)
        stats['metadata_only_events'] = len(events) - stats['shared_body_events']

    for name in ['session-metadata.json', 'artifact-write-events.json', 'attachment-inventory.json',
                 'image-inventory.json', 'detail-record-stats.json']:
        data[f'inventories/{name}'] = (args.exports / name).read_bytes()
    data['inventories/coverage.json'] = json.dumps(coverage, ensure_ascii=False, indent=2).encode()
    for name in ['diagnose-assets.mjs', 'asset-diagnostic.jsonl', 'formal-tests.tap', 's15-csv-audit.json',
                 'audit-environment.json', 'verify-evidence.py', 'package-evidence.py',
                 'document-checks.txt', 'worktree-diff.patch', 'export-detail-records.py']:
        data[f'audit/{name}'] = (args.exports / name).read_bytes()
    for path in (args.exports / 'http').glob('*'):
        data[f'audit/http/{path.name}'] = path.read_bytes()
    for path in sorted(args.exports.glob('contact-*.jpg')):
        data[f'visual/{path.name}'] = path.read_bytes()
    images = json.loads((args.exports / 'image-inventory.json').read_text())
    stream = io.StringIO()
    writer = csv.writer(stream, lineterminator='\n')
    writer.writerow(['image', 'sheet', 'visually_reviewed', 'method', 'fine_text_reviewed', 'sha256'])
    for i, row in enumerate(images):
        writer.writerow([row['path'], f'contact-{i // 9 + 1:02d}.jpg', 'yes', 'contact-sheet', 'no', row['sha256']])
    data['inventories/visual-review.csv'] = stream.getvalue().encode()

    paths = ['web/lib/formal-assets.mjs', 'web/lib/formal-runner.mjs', 'web/lib/formal-tool-process.mjs',
             'web/lib/formal-capabilities.mjs', 'web/lib/formal-python-process.mjs', 'web/lib/project.mjs',
             'web/lib/verified-assets.mjs', 'web/ide.mjs', 'web/_headers', 'web/serve.py',
             'scripts/build-web.sh', 'scripts/build-formal-python.py', 'scripts/package-release.sh',
             'tests/web/formal-assets.test.mjs', 'tests/web/formal-runner.test.mjs',
             'tests/e2e/openrouter-auth.spec.mjs', 'LICENSE']
    for path in paths:
        data[f'baseline/{path}'] = subprocess.check_output(['git', 'show', f'HEAD:{path}'], cwd=args.repo)
    for name in ['issue-21.json', 'pr-24.json']:
        if (args.exports / name).exists():
            data[f'audit/github/{name}'] = (args.exports / name).read_bytes()
    data['README.txt'] = (
        'Source sessions: 876fba8b52d442c9ac197f5aa1ec108e and d0a110d3f84f4346b049bc0f51829f8e\n'
        'Audit session: https://app.devin.ai/sessions/d978c0f0cabc4a0faac01e03c62e2cf8\n'
        'Base: e3c6e769aa2dfed1900546211ad852b601d78f85\n'
        'Original attachments are byte-identical. Other files are exports or derived audit data.\n'
        'All event IDs are retained. Internal reasoning/environment-state bodies are omitted.\n'
        'event-details.jsonl retains full returned JSON contents for public conversation/actions.\n'
        'events.jsonl is the normalized index; terminal/ decodes available terminal payloads.\n'
        'output_trunc fields are API-returned ranges, not guaranteed full stdout.\n'
        'Unattached VCD/FS/project ZIP and review script bodies were not recovered.\n'
        'Visual review: 90/90 screenshots on 10 contact sheets; not full-resolution text review.\n'
        'Existing unit tests: 120 passed. Loader diagnostic uses synthetic bytes, not executable WASM.\n'
        'No UI rerun, real board, real OpenRouter account, or Cloudflare settings test was performed.\n'
        'Original authorship and applicable licenses remain with each source; no new blanket license.\n'
        'Verify: python3 audit/verify-evidence.py evidence.zip\n'
    ).encode()

    sensitive_env = {name: value.encode() for name, value in os.environ.items()
                     if re.search(r'TOKEN|PASSWORD|SECRET|CREDENTIAL|API_KEY', name, re.I)
                     and len(value) >= 16 and not value.startswith('secret:')}
    hits = []
    token_pattern = re.compile(rb'(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,}|sk-or-v1-[a-f0-9]{40,})')
    for name, body in data.items():
        if name.lower().endswith(('.zip', '.png', '.jpg')):
            continue
        for env_name, value in sensitive_env.items():
            if value in body:
                hits.append({'file': name, 'environment_name': env_name})
        if token_pattern.search(body):
            hits.append({'file': name, 'pattern': 'token-like-value'})
    assert not hits, json.dumps(hits)

    stream = io.StringIO()
    writer = csv.writer(stream, lineterminator='\n')
    writer.writerow(['path', 'bytes', 'sha256'])
    for name, body in sorted(data.items()):
        writer.writerow([name, len(body), hashlib.sha256(body).hexdigest()])
    manifest = stream.getvalue().encode()
    data['evidence-files.csv'] = manifest
    args.output.mkdir(parents=True, exist_ok=True)
    archive_path = args.output / 'evidence.zip'
    with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
        for name, body in sorted(data.items()):
            archive.writestr(name, body)
    (args.output / 'evidence-files.csv').write_bytes(manifest)
    summary = {'archive': 'evidence.zip', 'bytes': archive_path.stat().st_size,
               'sha256': hashlib.sha256(archive_path.read_bytes()).hexdigest(), 'members': len(data),
               'source_attachments': len(original_hashes), 'source_attachment_hashes': original_hashes,
               'coverage': coverage, 'png_images': 90, 'browser_events': 166,
               'secret_scan': 'no known environment secrets or token-shaped values found in text members',
               'internal_event_bodies': 'omitted; metadata retained'}
    (args.output / 'evidence-summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({k: summary[k] for k in ['bytes', 'sha256', 'members', 'source_attachments']}))


if __name__ == '__main__':
    main()
