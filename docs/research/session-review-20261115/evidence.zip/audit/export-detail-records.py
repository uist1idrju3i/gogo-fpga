"""Recover exact JSON contents from paginated detail responses, omitting internal bodies."""
import collections
import json
from pathlib import Path
import re

from importlib.machinery import SourceFileLoader

root = Path(__file__).resolve().parent
package = SourceFileLoader('package_evidence', str(root / 'package-evidence.py')).load_module()
header = re.compile(r'^--- (event-[0-9a-f]+) ---\s*$', re.MULTILINE)
decoder = json.JSONDecoder()
stats = {}
for session_id in ['876fba8b52d442c9ac197f5aa1ec108e', 'd0a110d3f84f4346b049bc0f51829f8e']:
    index = [json.loads(l) for l in (root / f'{session_id}-all-events.jsonl').read_text().splitlines()]
    records = {}
    keys = collections.defaultdict(collections.Counter)
    string_maxima = collections.defaultdict(lambda: collections.defaultdict(int))
    for path in sorted((root / f'{session_id}-all-details').glob('*.json')):
        outer = json.loads(path.read_text())
        text = outer['structuredContent']['result']
        matches = list(header.finditer(text))
        for i, match in enumerate(matches):
            event_id = match.group(1)
            section = text[match.end():matches[i + 1].start() if i + 1 < len(matches) else len(text)]
            marker = section.index('  contents: ') + len('  contents: ')
            contents, end = decoder.raw_decode(section, marker)
            assert not section[end:].strip(), (path.name, event_id, 'extra data')
            assert event_id not in records
            typ = contents['type']
            record = {'event_id': event_id, 'type': typ, 'timestamp': contents.get('timestamp')}
            for field in ['direction', 'created_at']:
                value = re.search(rf'^  {field}: (.*)$', section, re.MULTILINE)
                if value:
                    record[field] = value.group(1)
            if typ in package.PUBLIC_EVENT_TYPES:
                record['contents'] = contents
                keys[typ].update(contents.keys())
                for key, value in contents.items():
                    if isinstance(value, str):
                        string_maxima[typ][key] = max(string_maxima[typ][key], len(value))
            else:
                record['details_omitted'] = 'internal_session_state'
            records[event_id] = record
    assert set(records) == {e['event_id'] for e in index}
    ordered = [records[e['event_id']] for e in index]
    (root / f'{session_id}-shareable-details.jsonl').write_text(''.join(json.dumps(e, ensure_ascii=False) + '\n' for e in ordered))
    stats[session_id] = {'events': len(records), 'keys': {k: dict(v) for k, v in keys.items()},
                         'maximum_string_lengths': {k: dict(v) for k, v in string_maxima.items()}}
    print(session_id, 'recovered detail records', len(records), 'bytes', (root / f'{session_id}-shareable-details.jsonl').stat().st_size)
(root / 'detail-record-stats.json').write_text(json.dumps(stats, indent=2) + '\n')
