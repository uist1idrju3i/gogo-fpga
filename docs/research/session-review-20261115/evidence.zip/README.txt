Source sessions: 876fba8b52d442c9ac197f5aa1ec108e and d0a110d3f84f4346b049bc0f51829f8e
Audit session: https://app.devin.ai/sessions/d978c0f0cabc4a0faac01e03c62e2cf8
Base: e3c6e769aa2dfed1900546211ad852b601d78f85
Original attachments are byte-identical. Other files are exports or derived audit data.
All event IDs are retained. Internal reasoning/environment-state bodies are omitted.
event-details.jsonl retains full returned JSON contents for public conversation/actions.
events.jsonl is the normalized index; terminal/ decodes available terminal payloads.
output_trunc fields are API-returned ranges, not guaranteed full stdout.
Unattached VCD/FS/project ZIP and review script bodies were not recovered.
Visual review: 90/90 screenshots on 10 contact sheets; not full-resolution text review.
Existing unit tests: 120 passed. Loader diagnostic uses synthetic bytes, not executable WASM.
No UI rerun, real board, real OpenRouter account, or Cloudflare settings test was performed.
Original authorship and applicable licenses remain with each source; no new blanket license.
Verify: python3 audit/verify-evidence.py evidence.zip
