module top(input clk);
  reg [2:0] count = 0;
  always @(posedge clk) begin
    count <= count + 1;
    assert(count != 3);
  end
endmodule
