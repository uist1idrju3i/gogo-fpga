`line 1 "work/libraries/darkriscv/sources/rtl/darkriscv.v" 0
/*
 * Copyright (c) 2018, Marcelo Samsoniuk
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 * * Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

`timescale 1ns / 1ps

// implemented opcodes:












// proprietary extension (custom-0)


// not implemented opcodes:
//`define FCC     7'b00011_11      // fencex


// configuration file


`line 1 "work/libraries/darkriscv/sources/rtl/../rtl/config.vh" 1
/*
 * Copyright (c) 2018, Marcelo Samsoniuk
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright notice, this
 *   list of conditions and the following disclaimer.
 *
 * * Redistributions in binary form must reproduce the above copyright notice,
 *   this list of conditions and the following disclaimer in the documentation
 *   and/or other materials provided with the distribution.
 *
 * * Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from
 *   this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

//`timescale 1ns / 1ps

// to port to a new board, use TESTMODE to test:
// - the reset button is working
// - the LED is blinking at 1Hz
// - the UART is looped
//`define __TESTMODE__

////////////////////////////////////////////////////////////////////////////////
// darkriscv configuration
////////////////////////////////////////////////////////////////////////////////

// pipeline stages:
//
// 2-stage version: core and memory in different clock edges result in less
// clock performance, but less losses when the program counter changes
// (pipeline flush = 1 clock).  Works like a 4-stage pipeline and remember
// the 68040 clock scheme, with instruction per clock = 1.  alternatively,
// it is possible work w/ 1 wait-state and 1 clock edge, but with a penalty
// in performance (instruction per clock = 0.5).
//
// 3-stage version: core and memory in the same clock edge require one extra
// stage in the pipeline, but keep a good performance most of time
// (instruction per clock = 1).  of course, read operations require 1
// wait-state, which means sometimes the read performance is reduced.


// RV32I vs RV32E:
//
// The difference between the RV32I and RV32E regarding the logic space is
// minimal in typical applications with modern 5 or 6 input LUT based FPGAs,
// but the RV32E is better with old 4 input LUT based FPGAs.
//`define __RV32E__

// BIG-ENDIAN:
//
// Although the core itself is bi-endian, the SoC, peripherals and firmware
// needs to be in sync in order to work correctly, so it is possible
// enable or disable the big-endian mode, which is usefull for network
// processing and other communication related stuff.
//`define __BIG__

// muti-threading support:
//
// Decreases clock performance by 20% (80MHz), but enables two or more
// contexts (threads) in the core. The threads work in symmetrical way,
// which means that they will start with the same exactly core parameters
// (same initial PC, same initial SP, etc). The boot.s code is designed
// to handle this difference and set each thread to different
// applications.
// Notes:
// a) threading is currently supported only in the 3-stage pipeline version.
// b) the old experimental "interrupt mode" was removed, which means that
//    the multi-thread mode does not make anything "visible" other than
//    increment the oport register.
// c) the threading in the non-interrupt mode switches when the program flow
//    changes, i.e. every jal instruction. When the core is idle, it is
//    probably in a jal loop.
// The number of threads must be 2**n (i.e. THREADS = 3 means 8 threads)
//`define __THREADS__ 3

// coprocessor interface
//
// The coprocessor interface allows to add new instructions to
// the custom-0 opcode without modifying the core itself
// the CPR_REQ is asserted when the custom opcode is matched
// the fct3/fct7 are outputted alongside with rs1/rs2/rd current values
// the RDW is the value written in the next cycle to the target register
// the user may use HLT to implement multi-cycle accelerators
//`define __COPROCESSOR__
















// flexbuzz interface (for compatibility):
//
// A new data bus interface similar to a well known c*ldfire bus interface,
// in a way that part of the bus routing is moved to the core, in a way that
// is possible support different bus widths (8, 16 or 32 bit) and endians
// more easily (the new interface is natively big-endian, but the endian can
// be adjusted in the bus interface dinamically).  Similarly to the standard
// 32-bit interface, the external logic must detect the RD/WR operation
// quick enough and assert HLT in order to insert wait-states and perform
// the required multiplexing to fit the DLEN operand size in the data bus
// width available.  As far as other blocks were added, in special
// DarkBridge, DarkRAM and DarkCache, such bus proved not so good, since we
// had to duplicate lots of code on that blocks, so we reverted to the
// previous concept and keep this option only for compatibility.
//`define __FLEXBUZZ__

// CSR support
//
// enable this to use CSR registers...  INTERRUPT and EBREAK use this in
// order to read some special exception registers.  Also, THREADS use this in
// order to identify the core number.




// Performance Counters
//
// The Performance Counters are a set of 64-bit registers that counts the
//number of clocks and number of instructions executed, so is possible
//measure the core performance.


// interrupt support
//
// The interrupt support in the core uses the machine registers mtvec and
// mepc, which means support the control special register instruction csrrw,
// in a way that is possible read/write the mtvec and mepc.
// the interrupt itself works like the thread switch, with the difference
// that:
// a) the PC will be saved in the mepc register
// b)the PC will receive the mtvec value
// c) single interrupt, which means that the mtvec offset is always zero
// The interrupt support cannot be used with threading (because makes no
// much sense?)... also, it requires the 3 stage pipeline (again, makes no
// much sense use it with the 2-stage pipeline).


// ebreak support
//
// ebreak enable live debug w/ gdb, with break points, single-step, etc...
// it basically consists in a single instruction that replace the normal
// instruction, so an exception will be triggered, which is like an interrupt,
// but with no real interrupt source.




// MUL support
//
// experimental and partial M-extension support, MUL/MULH/MULHSU/MULHU
// only...  in case of DIV/REM, trap and emulate by software is the current
// option!
//`define __MEXT__

// DBNZ support
//
// experimental custom instruction that decrement and branch if non-zero,
// found on other popular microprocessors!  as addition, it does not flush
// the pipeline, so it can run 1 or 2 additional instructions without
// performance impact, depending on pipeline length configuration.  as far
// as the tail length depends on pipeline setup, it is highly dependent of
// hand optimizations and must be used very carefuly!
//      jalr = imm[11:0] | rs1 | 000 | rd | 1100111
//      dbnz = imm[11:0] | rs1 | 000 | rd | 1100111, rs1 == rd
// example:
//                      ; x1 = len, x2 = sptr, x3 = dptr
//      loop:
//      lw x4,(x2)          ; x4 = *sptr
//      sw x4,(x3)          ; *dptr = x4
//      .word 0xff8090e7    ; dbnz x1,x1,test
//      addi x2,x2,4        ; sptr++
//      addi x3,x3,4        ; dptr++
//
//`define __DBNZ__

// instruction trace:
//
// prints the PC, the respective instruction and some useful information,
// skipping halt and flush, in order to track the instruction execution
// sequence.  traces are very useful to debug, since is possible dump the
// traces from a working core in order to debug a non-working core.  when
// trace is enabled, the UART print is blocked, also, the trace does not
// dump data when the core is in reset.
// the trace file is stored on "sim/darksocv.txt"
//`define __TRACE__
//`define __TRACEFULL__

// performance measurement:
//
// The performance measurement can be done in the simulation level by
// eabling the __PERFMETER__ define, in order to check how the clock cycles
// are used in the core. The report is displayed when the FINISH_REQ signal
// is actived by the UART.
// the performance counters does not count when the core is in reset.


// initial PC
//
// Typically, the PC is set [by HW] to address 0, representing the start of
// ROM memory and the SP is set [by SW] to the final of RAM memory.  In the
// linker, the start of ROM memory matches with the .text area, which is
// defined in the boot.c code and the start of RAM memory matches with the
// .data and other volatile data, in a way that the stack can be positioned
// in the top of RAM and does not match with the .data.


////////////////////////////////////////////////////////////////////////////////
// darksocv configuration:
////////////////////////////////////////////////////////////////////////////////

// harvard architecture
//
// darkriscv core is *always* harvard, but it possible multiplex the instr.
// and data buses over the time on the SoC level, in a way that it mimics a
// classic von neumann architecture, which is useful for single-port memory,
// such as SDRAMs, PSRAM, etc. when multiplexed, the instruction fetch turns
// to be very slow, so caches are essential with this scenario!


// cache depth
//
// when enabled, the caches will try map and store the read operations, in a
// way that future read operations in the same address will be faster! it is
// specially applicable to non-harvard SoC configuration, since that the
// harvard SoC configuration is faster than the cache!
// the cache depth N means that the each cache will be 32-bit x 2^N








// interactive simulation:
//
// When enabled, will trick the simulator in order to enable interactive
// access via the stdin, in a way that is possible type interactive commands,
// which will make your simulator crazy! unfortunately, it works only with
// iverilog... at least, Xilinx ISIM does not liket the $fgetc()
//`define __INTERACTIVE__

// icarus register debug:
//
// As most people observed, the icarus verilog does not dump the register
// bank because icarus does not dump arrays by default. However, it is possible
// activate this special option in order to dump the register bank. This
// makes no effect in other simulators, but it appears as a warning.
//`define __REGDUMP__

// memory size:
//
// The current test firmware requires 8KB of memory, but it depends of the
// memory layout: whenthe I-bus and D-bus are both attached in the same BRAM,
// it is possible assume that 8kB is enough, but when the I-bus and D-bus are
// attached to separate memories, the I-BRAM requires around 5KB and the
// D-BRAM requires about 1.5KB. A safe solution is just simply and set the
// size as the same.
// The size is defined as 2**MLEN, i.e. the address bits used in the memory.
// WARNING: this setup must match with the src/darksocv.ld.src file!

                // 15: 32kB, for coremark

// read-modify-write cycle:
//
// Generate RMW cycles when writing in the memory. This option basically
// makes the read and write cycle symmetric and may work better in the cases
// when the 32-bit memory does not support separate write enables for
// separate 16-bit and 8-bit words. Typically, the RMW cycle results in a
// decrease of 5% in the performance (not the clock, but the instruction
// pipeline eficiency) due to memory wait-states.
//`define __RMW_CYCLE__

// bram wait states
//
// to simulate high latency memories, is possible set the number of wait-states
// for bram here! case not configured, wait-states defaults to 1.
//`define __WAITSTATE__ 3

// UART speed is set in bits per second, typically 115200 bps:
//`define __UARTSPEED__ 115200

// UART queue:
//
// Optional RX/TX queue for communication oriented applications. The concept
// foreseen 256 bytes for TX and RX, in a way that frames up to 128 bytes can
// be easily exchanged via UART. the queue size is defined as 2**N:
//`define __UARTQUEUE__ 8 // not working well, need check...

////////////////////////////////////////////////////////////////////////////////
// board definition:
////////////////////////////////////////////////////////////////////////////////

// The board is automatically defined in the xst/xise files via Makefile or
// ISE. Case it is not the case, please define you board name here:
//`define AVNET_MICROBOARD_LX9
//`define XILINX_AC701_A200
//`define QMTECH_SDRAM_LX16

// the following defines are automatically defined:

















// the board definition is done on the tool, otherwise we assume simulation






























































































































































































    
    
    //`define __SDRAM__ 1






// darkuart baudrate automtically calculated according to board clock:


  




// register number depends of CPU type RV32[EI] and number of threads











    


        
    



    



    


`line 56 "work/libraries/darkriscv/sources/rtl/darkriscv.v" 2

module darkriscv
#(
    parameter CPTR = 0
)
(
    input             CLK,   // clock
    input             RES,   // reset


    input             IRQ,   // interrupt request


    // instr-bus

    output            IDREQ, // inst req
    output     [31:0] IADDR, // inst addr bus
    input      [31:0] IDATA, // inst data bus
    input             IDACK, // inst ack
    input             IBERR, // inst bus error

    // ddata-bus

    output            DDREQ,// data req
    output     [31:0] DADDR,// data addr bus
    output     [ 2:0] DLEN, // data length
    output     [ 3:0] DBE,  // data byte enable
    output            DRW,  // data read/write
    output            DRD,  // data read
    output            DWR,  // data write
    output     [31:0] DATAO,// data bus (output)
    input      [31:0] DATAI,// data bus (input)
    input             DDACK,// data ack
    input             DBERR,// data bus error

















    output [3:0]  DEBUG       // old-school osciloscope based debug! :)
);

    // dummy 32-bit words w/ all-0s and all-1s:

    wire [31:0] ALL0  = 0;
    wire [31:0] ALL1  = -1;

    // core reset logic

    reg XRES = 1;






    always@(posedge CLK)
    begin




        XRES <= RES;

    end

    // pipeline flow control when halted (HLT=1)

    wire HLT =



                (DDREQ?!DDACK:0)||      // wheh DDREQ=1, wait DDACK
                (IDREQ?!IDACK:0);       // when IDREQ=1, wait IDACK

    // instruction fetch logic




        reg [31:0] IFPC;                                // 32-bit program counter IF state


    assign IDREQ   = !XRES;

    


        assign IADDR = IFPC;
    

    // switch IDATA according to the endian




    wire [31:0] IDATA1 = IDATA;




    // only for halt control
    reg        HLT2   = 0;
    reg [31:0] IDATA2 = 0;

    always@(posedge CLK)
    begin
        HLT2 <= HLT;

        // clock in IDATA2 when HLT transitions
        if(HLT2^HLT) IDATA2 <= IDATA1;
    end

    // HLT-aware instruction data for decode stage
    wire[31:0] IDATAX = XRES ? 0 :
                        HLT2 ? IDATA2 :
                               IDATA1;

    // decode: IDATA is break apart as described in the RV32I specification



    // eXecute stage instruction data (next pipeline stage)
    reg [31:0] XIDATA;

    reg XLUI, XAUIPC, XJAL, XJALR, XBCC, XLCC, XSCC, XMCC, XRCC, XCUS, XSYS; //, XFCC;





    reg [31:0] XSIMM;
    reg [31:0] XUIMM;

    always@(posedge CLK)
    begin
        XIDATA <= HLT ? XIDATA : IDATAX;

        XLUI   <= HLT ? XLUI   : IDATAX[6:0]==7'b01101_11;
        XAUIPC <= HLT ? XAUIPC : IDATAX[6:0]==7'b00101_11;
        XJAL   <= HLT ? XJAL   : IDATAX[6:0]==7'b11011_11;




        XJALR  <= HLT ? XJALR  : IDATAX[6:0]==7'b11001_11;

        XBCC   <= HLT ? XBCC   : IDATAX[6:0]==7'b11000_11;
        XLCC   <= HLT ? XLCC   : IDATAX[6:0]==7'b00000_11;
        XSCC   <= HLT ? XSCC   : IDATAX[6:0]==7'b01000_11;
        XMCC   <= HLT ? XMCC   : IDATAX[6:0]==7'b00100_11;

        XRCC   <= HLT ? XRCC   : IDATAX[6:0]==7'b01100_11;
        XCUS   <= HLT ? XCUS   : IDATAX[6:0]==7'b00010_11;
        //XFCC   <= HLT ? XFCC   : IDATAX[6:0]==`FCC;
        XSYS   <= HLT ? XSYS   : IDATAX[6:0]==7'b11100_11;

        // sign extended immediate, according to the instruction type:

        XSIMM  <= HLT ? XSIMM :
                 IDATAX[6:0]==7'b01000_11 ? { IDATAX[31] ? ALL1[31:12]:ALL0[31:12], IDATAX[31:25],IDATAX[11:7] } : // s-type
                 IDATAX[6:0]==7'b11000_11 ? { IDATAX[31] ? ALL1[31:13]:ALL0[31:13], IDATAX[31],IDATAX[7],IDATAX[30:25],IDATAX[11:8],ALL0[0] } : // b-type
                 IDATAX[6:0]==7'b11011_11 ? { IDATAX[31] ? ALL1[31:21]:ALL0[31:21], IDATAX[31], IDATAX[19:12], IDATAX[20], IDATAX[30:21], ALL0[0] } : // j-type
                 IDATAX[6:0]==7'b01101_11||
                 IDATAX[6:0]==7'b00101_11 ? { IDATAX[31:12], ALL0[11:0] } : // u-type
                                      { IDATAX[31] ? ALL1[31:12]:ALL0[31:12], IDATAX[31:20] }; // i-type

        // zero-extended (unsigned) immediate, according to the instruction type:

        XUIMM  <= HLT ? XUIMM :
                 IDATAX[6:0]==7'b01000_11 ? { ALL0[31:12], IDATAX[31:25],IDATAX[11:7] } : // s-type
                 IDATAX[6:0]==7'b11000_11 ? { ALL0[31:13], IDATAX[31],IDATAX[7],IDATAX[30:25],IDATAX[11:8],ALL0[0] } : // b-type
                 IDATAX[6:0]==7'b11011_11 ? { ALL0[31:21], IDATAX[31], IDATAX[19:12], IDATAX[20], IDATAX[30:21], ALL0[0] } : // j-type
                 IDATAX[6:0]==7'b01101_11||
                 IDATAX[6:0]==7'b00101_11 ? { IDATAX[31:12], ALL0[11:0] } : // u-type
                                      { ALL0[31:12], IDATAX[31:20] }; // i-type
    end

    // how many cycles left to start instruction execution
    reg [1:0] FLUSH = -1;  // flush instruction pipeline






































































    




        wire [4:0] DPTR   = XIDATA[11: 7]; // set SP_RESET when RES==1
        wire [4:0] S1PTR  = XIDATA[19:15];
        wire [4:0] S2PTR  = XIDATA[24:20];
    


    wire [6:0] OPCODE = FLUSH ? 0 : XIDATA[6:0]; // unused
    wire [2:0] FCT3   = XIDATA[14:12];
    wire [6:0] FCT7   = XIDATA[31:25];

    wire [31:0] SIMM  = XSIMM;
    wire [31:0] UIMM  = XUIMM;

    // main opcode decoder:

    wire    LUI = FLUSH ? 0 : XLUI;   // OPCODE==7'b0110111;
    wire  AUIPC = FLUSH ? 0 : XAUIPC; // OPCODE==7'b0010111;
    wire    JAL = FLUSH ? 0 : XJAL;   // OPCODE==7'b1101111;
    wire   JALR = FLUSH ? 0 : XJALR;  // OPCODE==7'b1100111;



    wire    BCC = FLUSH ? 0 : XBCC; // OPCODE==7'b1100011; //FCT3
    wire    LCC = FLUSH ? 0 : XLCC; // OPCODE==7'b0000011; //FCT3
    wire    SCC = FLUSH ? 0 : XSCC; // OPCODE==7'b0100011; //FCT3
    wire    MCC = FLUSH ? 0 : XMCC; // OPCODE==7'b0010011; //FCT3

    wire    RCC = FLUSH ? 0 : XRCC; // OPCODE==7'b0110011; //FCT3
    wire    CUS = FLUSH ? 0 : XCUS; // OPCODE==7'b0110011; //FCT3
    //wire    FCC = FLUSH ? 0 : XFCC; // OPCODE==7'b0001111; //FCT3
    wire    SYS = FLUSH ? 0 : XSYS; // OPCODE==7'b1110011; //FCT3



    reg [31:0] REGS [0:32-1];	// synthesis attribute ram_style of REGS is "distributed";


    reg [31:0] IDPC;            // 32-bit program counter for ID stage







    reg [31:0] PC;		            // 32-bit program counter for EX stage







    // source-1 and source-2 register selection

    wire          [31:0] U1REG = REGS[S1PTR];
    wire          [31:0] U2REG = REGS[S2PTR];
    wire          [31:0] DREG  = REGS[DPTR];

    wire signed   [31:0] S1REG = U1REG;
    wire signed   [31:0] S2REG = U2REG;


    // SL-group of instructions (OPCODE==7'b0100011 for S, OPCODE==7'b0000011 for L)










    



















        wire [31:0] LDATA = FCT3==0||FCT3==4 ? ( DADDR[1:0]==3 ? { FCT3==0&&DATAI[31] ? ALL1[31: 8]:ALL0[31: 8] , DATAI[31:24] } :
                                                 DADDR[1:0]==2 ? { FCT3==0&&DATAI[23] ? ALL1[31: 8]:ALL0[31: 8] , DATAI[23:16] } :
                                                 DADDR[1:0]==1 ? { FCT3==0&&DATAI[15] ? ALL1[31: 8]:ALL0[31: 8] , DATAI[15: 8] } :
                                                                 { FCT3==0&&DATAI[ 7] ? ALL1[31: 8]:ALL0[31: 8] , DATAI[ 7: 0] } ):
                            FCT3==1||FCT3==5 ? ( DADDR[1]==1   ? { FCT3==1&&DATAI[31] ? ALL1[31:16]:ALL0[31:16] , DATAI[31:16] } :
                                                                 { FCT3==1&&DATAI[15] ? ALL1[31:16]:ALL0[31:16] , DATAI[15: 0] } ) :
                                                 DATAI;

        wire [31:0] SDATA = FCT3==0 ? ( DADDR[1:0]==3 ? { U2REG[ 7: 0], ALL0 [23:0] } :
                                        DADDR[1:0]==2 ? { ALL0 [31:24], U2REG[ 7:0], ALL0[15:0] } :
                                        DADDR[1:0]==1 ? { ALL0 [31:16], U2REG[ 7:0], ALL0[7:0] } :
                                                        { ALL0 [31: 8], U2REG[ 7:0] } ) :
                            FCT3==1 ? ( DADDR[1]==1   ? { U2REG[15: 0], ALL0 [15:0] } :
                                                        { ALL0 [31:16], U2REG[15:0] } ) :
                                        U2REG;
    


    // C-group: CSRRW

    wire EBRK = SYS && FCT3==0 && XIDATA[31:20]==12'b000000000001; // ebreak always decodable, for simulation

    // exceptions

    wire IERR = FLUSH ? 0 : !(XLUI||XAUIPC||XJAL||XJALR||XBCC||XLCC||XSCC||XMCC||XRCC||XCUS||XSYS);

    wire DBER = DBERR;
    wire IBER = IBERR;
    wire DAER = DLEN==2 ? DADDR[0]!=0 : DLEN==4 ? DADDR[1:0]!=0 : 0;
    wire IAER = IADDR[1:0]!=0;



    wire CSRX  = SYS && FCT3[1:0];

    
        reg [31:0] MSTATUS  = 0;
        reg [31:0] MSCRATCH = 0;
        reg [31:0] MCAUSE   = 0;
        reg [31:0] MEPC     = 0;
        reg [31:0] MTVEC    = 0;
        reg [31:0] MIE      = 0;
        reg [31:0] MIP      = 0;

        wire MRET = SYS && FCT3==0 && XIDATA[31:20]==12'b001100000010;
    

    
        reg [31:0] SSTATUS  = 0;
        reg [31:0] SSCRATCH = 0;
        reg [31:0] SCAUSE   = 0;
        reg [31:0] SEPC     = 0;
        reg [31:0] STVEC    = 0;
        reg [31:0] SIE      = 0;
        reg [31:0] SIP      = 0;

        wire SRET = SYS && FCT3==0 && XIDATA[31:20]==12'b000100000010;
    

    
		reg [63:0] CSRCLK = 0;
		reg [63:0] CSRINS = 0;
		always@(posedge CLK)
		begin
			if(!XRES)
			begin
				CSRCLK = CSRCLK+1;
				if(!HLT & !(|FLUSH))
					CSRINS = CSRINS+1;
			end
		end
    

    wire [31:0] CRDATA =
    


                        XIDATA[31:20]==12'hf14 ? CPTR  : // core number
    
    
                        XIDATA[31:20]==12'h344 ? MIP      : // machine interrupt pending
                        XIDATA[31:20]==12'h304 ? MIE      : // machine interrupt enable
                        XIDATA[31:20]==12'h341 ? MEPC     : // machine exception PC
                        XIDATA[31:20]==12'h342 ? MCAUSE   : // machine expection cause
                        XIDATA[31:20]==12'h305 ? MTVEC    : // machine vector table
                        XIDATA[31:20]==12'h300 ? MSTATUS  : // machine status
                        XIDATA[31:20]==12'h340 ? MSCRATCH : // machine status
    
    
                        XIDATA[31:20]==12'h144 ? SIP      : // machine interrupt pending
                        XIDATA[31:20]==12'h104 ? SIE      : // machine interrupt enable
                        XIDATA[31:20]==12'h141 ? SEPC     : // machine exception PC
                        XIDATA[31:20]==12'h142 ? SCAUSE   : // machine expection cause
                        XIDATA[31:20]==12'h105 ? STVEC    : // machine vector table
                        XIDATA[31:20]==12'h100 ? SSTATUS  : // machine status
                        XIDATA[31:20]==12'h140 ? SSCRATCH : // machine status
    
    
						XIDATA[31:20]==12'hC00 ? CSRCLK[31:0]  :
						XIDATA[31:20]==12'hC02 ? CSRINS[31:0]  :
						XIDATA[31:20]==12'hC80 ? CSRCLK[63:32] :
						XIDATA[31:20]==12'hC82 ? CSRINS[63:32] :
    
                                                 0;	 // unknown

    wire [31:0] CRMASK = FCT3[2] ? XIDATA[19:15] : U1REG;
    wire [31:0] WRDATA = FCT3[1:0]==3 ? (CRDATA & ~CRMASK) : FCT3[1:0]==2 ? (CRDATA | CRMASK) : CRMASK;




    // RM-group of instructions (OPCODEs==7'b0010011/7'b0110011), merged! src=immediate(M)/register(R)

    wire signed [31:0] S2REGX = XMCC ? SIMM : S2REG;
    wire        [31:0] U2REGX = XMCC ? SIMM : U2REG;










    wire [31:0] RMDATA =








                         FCT3==7 ? U1REG&S2REGX :
                         FCT3==6 ? U1REG|S2REGX :
                         FCT3==4 ? U1REG^S2REGX :
                         FCT3==3 ? U1REG<U2REGX : // unsigned
                         FCT3==2 ? S1REG<S2REGX : // signed
                         FCT3==0 ? (XRCC&&FCT7[5] ? U1REG-S2REGX : U1REG+S2REGX) :
                         FCT3==1 ? S1REG<<U2REGX[4:0] :
                         //FCT3==5 ?
                         !FCT7[5] ? S1REG>>U2REGX[4:0] :



                                   $signed(S1REG>>>U2REGX[4:0]);  // (FCT7[5] ? U1REG>>>U2REG[4:0] :











    // J/B-group of instructions (OPCODE==7'b1100011)

    wire BMUX       = FCT3==7 && U1REG>=U2REG  || // bgeu
                      FCT3==6 && U1REG< U2REGX || // bltu
                      FCT3==5 && S1REG>=S2REG  || // bge
                      FCT3==4 && S1REG< S2REGX || // blt
                      FCT3==1 && U1REG!=U2REGX || // bne
                      FCT3==0 && U1REG==U2REGX; // beq

    wire [31:0] PCSIMM = PC+SIMM;
    wire        JREQ = JAL||JALR||(BCC && BMUX);
    wire [31:0] JVAL = { JALR ? DADDR[31:2] : PCSIMM[31:2], 2'b00 }; // SIMM + (JALR ? U1REG : PC);





    always@(posedge CLK)
    begin

        FLUSH <= XRES ? 2 :         // on reset wait 2 cycles (fill the pipeline)
                  HLT ? FLUSH :     // on halt do nothing
                FLUSH ? FLUSH-1 :   // if-nonzero -> decrement
    
          IERR||DBER||IBER||IAER||DAER ? 2 : // misc errors
                                  EBRK ? 2 : // ebreak jmps to system level, i.e. sepc = PC; PC = stvec
                                  SRET ? 2 : // sret returns from system level, i.e. PC = sepc
    
    
                 MRET ? 2 :         // mret returns from interrupt, i.e. PC = mepc
    
                 JREQ ? 2 : 0;      // flush the pipeline! (when jump requested)








    
        MIP[11] <= XRES ? 0 : IRQ&&MSTATUS[3]&&MIE[11]&&!SIP[1]&&MTVEC;
    



        if(XRES)
        begin
            MTVEC    <= 0;
            MEPC     <= 0;
            MIE      <= 0;
            MCAUSE   <= 0;
            MSTATUS  <= 0;
            MSCRATCH <= 0;
        end
        else
        if(!HLT && !FLUSH)
        begin
            if(CSRX)
            begin
                case(XIDATA[31:20])
                    12'h300: MSTATUS  <= WRDATA;
                    12'h340: MSCRATCH <= WRDATA;
                    12'h305: MTVEC    <= WRDATA;
                    12'h341: MEPC     <= WRDATA;
                    12'h304: MIE      <= WRDATA;
                endcase
            end
            else
            if(MIP[11] && JREQ)
            begin
                MEPC   <= JVAL;             // interrupt saves the next PC!
                MSTATUS[3] <= 0;            // no interrupts when handling ebreak!
                MSTATUS[7] <= MSTATUS[3];   // copy old MIE bit
                MCAUSE <= 32'h8000000b;     // ext interrupt
            end
            else
            if(MRET)
            begin
                MSTATUS[3] <= MSTATUS[7]; // return last MIE bit
            end
        end




        if(XRES)
        begin
            STVEC    <= 0;
            SEPC     <= 0;
            SIE      <= 0;
            SIP      <= 0;
            SCAUSE   <= 0;
            SSTATUS  <= 0;
            SSCRATCH <= 0;
        end
        else
        if(!HLT||!FLUSH)
        begin
            if(STVEC&&(IAER||IBER||IERR||EBRK||DAER||DBER)) // ebreak cannot be blocked, but need STVEC not zero!
            begin
                SEPC   <= PC;               // ebreak saves the current PC!
                SSTATUS[1] <= 0;            // no interrupts when handling ebreak!
                SSTATUS[5] <= SSTATUS[1];   // copy old MIE bit

                SCAUSE <=      IAER ? 32'd0 :
                               IBER ? 32'd1 :
                               IERR ? 32'd2 :
                               EBRK ? 32'd3 :
                          DAER&&DRD ? 32'd4 :
                          DBER&&DRD ? 32'd5 :
                          DAER&&DWR ? 32'd6 :
                          DBER&&DWR ? 32'd7 :
                                    -1;

                SIP[1] <= 1;                // set when ebreak!
            end
            else
            if(CSRX)
            begin
                case(XIDATA[31:20])
                    12'h100: SSTATUS  <= WRDATA;
                    12'h140: SSCRATCH <= WRDATA;
                    12'h105: STVEC    <= WRDATA;
                    12'h141: SEPC     <= WRDATA;
                    12'h104: SIE      <= WRDATA;
                endcase
            end
            else
            if(SRET)
            begin
                SSTATUS[3] <= SSTATUS[7]; // return last MIE bit
                SIP[1] <= 0;              //return from ebreak
            end
        end






        REGS[DPTR] <=   XRES||DPTR[4:0]==0 ? 0  :        // reset x0

                       HLT ? DREG :        // halt
                       LCC ? LDATA :
                     AUIPC ? PCSIMM :



                      JAL||
                      JALR ? IDPC :
                       LUI ? SIMM :
                  MCC||RCC ? RMDATA:





                       CSRX ? CRDATA :

                             DREG;

    


















        
            IDPC <= HLT ? IDPC : IFPC;
        

        IFPC <=  XRES ? 32'd0 : HLT ? IFPC :   // reset and halt
        
                     SRET ? SEPC :  // return from system call
                     STVEC&&
                     (IAER||
                     IBER||
                     IERR||
                     EBRK||
                     DAER||
                     DBER) ? STVEC : // ebreak causes an system call
        

        
                     MRET ? MEPC :  // return from interrupt
                    MIP[11]&&
                    JREQ ? MTVEC : // pending interrupt + pipeline flush
        
                     JREQ ? JVAL :                    // jmp/bra
        


                            IFPC+4;                   // normal flow

    

        PC   <= HLT ? PC : IDPC; // EX stage program counter
    end

    // IO and memory interface

    assign DATAO = SDATA;
    assign DADDR = U1REG + SIMM;

    // based in the Scc and Lcc

    assign DRW      = !SCC;
    assign DLEN[0] = (SCC||LCC)&&FCT3[1:0]==0; // byte
    assign DLEN[1] = (SCC||LCC)&&FCT3[1:0]==1; // word
    assign DLEN[2] = (SCC||LCC)&&FCT3[1:0]==2; // long











    assign DBE = FCT3==0||FCT3==4 ? ( DADDR[1:0]==3 ? 4'b1000 : // sb/lb
                                      DADDR[1:0]==2 ? 4'b0100 :
                                      DADDR[1:0]==1 ? 4'b0010 :
                                                      4'b0001 ) :
                 FCT3==1||FCT3==5 ? ( DADDR[1]==1   ? 4'b1100 : // sh/lh
                                                      4'b0011 ) :
                                                      4'b1111; // sw/lw


    assign DWR     = SCC;
    assign DRD     = LCC;
    assign DDREQ   = SCC||LCC;



    assign DEBUG = { IRQ, MIP, MIE, MRET };











































































































































endmodule

`line 1 "work/src/top.v" 0
// SPDX-License-Identifier: BSD-3-Clause
module top(input wire clk, output wire led);

`line 1 "work/src/bus.vh" 1
// SPDX-License-Identifier: BSD-3-Clause
  wire resetn;
  wire [7:0] sample;
  wire [31:0] i_addr, i_rdata, d_addr, d_wdata, d_rdata, gpio;
  wire [3:0] d_wstrb;
  wire i_req, i_ack, d_req, d_ack;
  cpu_startup startup(.clk(clk), .resetn(resetn), .sample(sample));
  cpu_memory memory(
    .clk(clk), .resetn(resetn), .sample(sample),
    .i_addr(i_addr), .i_req(i_req), .i_rdata(i_rdata), .i_ack(i_ack),
    .d_addr(d_addr), .d_wdata(d_wdata), .d_wstrb(d_wstrb), .d_req(d_req),
    .d_rdata(d_rdata), .d_ack(d_ack), .gpio(gpio)
  );
  assign led = gpio[0];

`line 4 "work/src/top.v" 2
  wire [3:0] select;
  wire writing;
  reg [31:0] instruction = 0;
  always @(posedge clk) instruction <= i_rdata;
  assign d_wstrb = writing ? select : 4'b0;
  darkriscv #(.CPTR(0)) cpu(
    .CLK(clk), .RES(!resetn), .IRQ(1'b0),
    .IDREQ(i_req), .IADDR(i_addr), .IDATA(instruction), .IDACK(i_ack), .IBERR(1'b0),
    .DDREQ(d_req), .DADDR(d_addr), .DBE(select), .DWR(writing),
    .DATAO(d_wdata), .DATAI(d_rdata), .DDACK(d_ack), .DBERR(1'b0)
  );
endmodule

`line 1 "work/src/memory.v" 0
// SPDX-License-Identifier: BSD-3-Clause
module cpu_memory #(parameter ROM_WORDS = 18)(
  input wire clk, resetn,
  input wire [7:0] sample,
  input wire [31:0] i_addr,
  input wire i_req,
  output wire [31:0] i_rdata,
  output wire i_ack,
  input wire [31:0] d_addr, d_wdata,
  input wire [3:0] d_wstrb,
  input wire d_req,
  output wire [31:0] d_rdata,
  output wire d_ack,
  output reg [31:0] gpio = 0
);
  reg [31:0] rom [0:ROM_WORDS-1];
  reg [31:0] ram [0:7];
  integer lane;
  initial $readmemh("src/program.hex", rom);
  assign i_rdata = i_addr < ROM_WORDS * 4 ? rom[i_addr[6:2]] : 32'h0000006f;
  assign i_ack = i_req && resetn;
  assign d_ack = d_req && resetn;
  assign d_rdata = d_addr == 516 ? {24'b0, sample} :
                   d_addr >= 256 && d_addr < 288 ? ram[d_addr[4:2]] :
                   d_addr < ROM_WORDS * 4 ? rom[d_addr[6:2]] : 32'b0;
  always @(posedge clk) begin
    if (!resetn) gpio <= 0;
    else if (d_req && d_ack) begin
      if (d_addr == 512 && d_wstrb == 4'b1111) gpio <= d_wdata;
      if (d_addr >= 256 && d_addr < 288)
        for (lane = 0; lane < 4; lane = lane + 1)
          if (d_wstrb[lane]) ram[d_addr[4:2]][lane*8 +: 8] <= d_wdata[lane*8 +: 8];
    end
  end
endmodule

module cpu_startup(input wire clk, output wire resetn, output reg [7:0] sample = 0);
  reg [3:0] reset_count = 0;
  assign resetn = &reset_count;
  always @(posedge clk) begin
    if (!resetn) reset_count <= reset_count + 1'b1;
    sample <= sample + 1'b1;
  end
endmodule

`line 1 "work/src/tb.v" 0
`timescale 1ns/1ps
module tb;
  reg clk = 0;
  wire led;
  top dut(.clk(clk), .led(led));
  defparam dut.memory.ROM_WORDS = 18;
  integer cycles = 0, writes = 0, stores = 0, reads = 0, fetches = 0;
  integer index = 0, seed = 0, samples = 0;
  reg [31:0] expected, last_gpio = 0;
  always #5 clk = ~clk;
  initial begin
    $dumpfile("wave.vcd");
    $dumpvars(0, clk, led, writes, stores, reads, fetches, seed);
    force dut.resetn = 1'b0;
    
    
  end
  always @(posedge clk) begin
    cycles = cycles + 1;
    if (cycles == 100000) $fatal(1, "CPU_TIMEOUT");
    if (dut.resetn) begin
      if (dut.i_req && dut.i_ack) fetches = fetches + 1;
      if (dut.d_req && dut.d_ack) begin
        if (dut.d_addr == 516 && dut.d_wstrb == 0) begin
          if (samples != 0 && seed === dut.d_rdata) $fatal(1, "CPU_SAMPLE_STATIC");
          seed = dut.d_rdata;
          samples = samples + 1;
          index = 0;
        end
        expected = (seed ^ 85) + index;
        if (dut.d_addr >= 256 && dut.d_addr < 288) begin
          if (samples == 0 || dut.d_addr !== 256 + index * 4)
            $fatal(1, "CPU_MEMORY_ADDRESS");
          if (dut.d_wstrb == 15) begin
            if (dut.d_wdata !== expected) $fatal(1, "CPU_MEMORY_WRITE");
            stores = stores + 1;
          end else if (dut.d_wstrb == 0) begin
            if (dut.d_rdata !== expected) $fatal(1, "CPU_MEMORY_READ");
            reads = reads + 1;
          end else $fatal(1, "CPU_BYTE_ENABLE");
        end
        if (dut.d_addr == 512 && dut.d_wstrb != 0) begin
          if (dut.d_wstrb != 15 || dut.d_wdata !== expected + 0)
            $fatal(1, "CPU_GPIO_MISMATCH");
          writes = writes + 1;
          last_gpio = dut.d_wdata;
          index = index + 1;
          if (writes == 16) begin
            if (stores != 16 || reads != 16 || samples != 2 || fetches < 100)
              $fatal(1, "CPU_EXECUTION_EVIDENCE");
          end
        end
      end
    end
  end
  always @(negedge clk) begin
    if (writes != 0 && led !== last_gpio[0]) $fatal(1, "CPU_GPIO_OUTPUT");
    if (writes == 16) begin
      $display("CPU_FUNCTION_OK writes=%0d stores=%0d reads=%0d samples=%0d", writes, stores, reads, samples);
      $finish;
    end
  end
endmodule
